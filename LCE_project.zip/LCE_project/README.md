# LCE-KMITL
When you type long text on website and you forget to change language on your keyboard, this chrome extension will automatic change your language and we will add it to Right-click menu for more convenience.
So, you don't have to waste time to delete text and type again